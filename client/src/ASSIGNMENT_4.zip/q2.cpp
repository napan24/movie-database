#include<bits/stdc++.h>
using namespace std;

struct Graph
{
    int V, E;
    vector< pair<int, pair<int, int>> > edges;
    Graph(int V, int E)
    {
        this->V = V;
        this->E = E;
    }
    void addEdge(int u, int v, int w)
    {
        edges.push_back({w, {u, v}});
    }
    int kruskalMST();
};
struct DisjointSets
{
    int *parent, *rank;
    int n;
    DisjointSets(int n)
    {
        this->n = n;
        parent = new int[n+1];
        rank = new int[n+1];
        for (int i = 0; i <= n; i++)
        {
            rank[i] = 0;
            parent[i] = i;
        }
    }
    int find(int u)
    {
        if (u != parent[u])
            parent[u] = find(parent[u]);
        return parent[u];
    }
    void merge(int x, int y)
    {
        x = find(x), y = find(y); 
        if (rank[x] > rank[y])
            parent[y] = x;
        else
            parent[x] = y;
  
        if (rank[x] == rank[y])
            rank[y]++;
    }
};  
int Graph::kruskalMST()
{
    int total_weight = 0;
    sort(edges.begin(), edges.end());
    DisjointSets ds(V);
    vector< pair<int, pair<int, int>> >::iterator it;
    for (it=edges.begin(); it!=edges.end(); it++)
    {
        int u = it->second.first;
        int v = it->second.second;
  
        int a = ds.find(u);
        int b = ds.find(v);
        if (a != b)
        {
            cout << u << " - " << v << endl;
            total_weight += it->first;
            ds.merge(a, b);
        }
    }
    return total_weight;
}
int main()
{
    //a=0 b=1 c=2 d=3 e=4 f=5 g=6
    int V = 6, E = 28;
    Graph g(V, E);
    g.addEdge(0,3 , 5);
    g.addEdge(0,2 ,21 );
    g.addEdge(0,5 , 7);
    g.addEdge(0,1 , 14);
    g.addEdge(1,0 , 14);
    g.addEdge(1,5 , 2);
    g.addEdge(1,2 , 15);
    g.addEdge(1,6 , 19);
    g.addEdge(2,0 , 21);
    g.addEdge(2,1, 14);
    g.addEdge(2,6 , 3);
    g.addEdge(2,4 , 4);
    g.addEdge(3,0 , 5);
    g.addEdge(3,5 , 13);
    g.addEdge(3,4 , 22);
    g.addEdge(4,6 , 2);
    g.addEdge(4,2 , 4);
    g.addEdge(4,5 , 15);
    g.addEdge(4,3 , 22);
    g.addEdge(5,0 , 7);
    g.addEdge(5,3 , 13);
    g.addEdge(5,4 , 15);
    g.addEdge(5,6 , 18);
    g.addEdge(5,1 , 2);
    g.addEdge(6,2 ,3);
    g.addEdge(6,1 , 19);
    g.addEdge(6,5 , 18);
    g.addEdge(6,4 , 2);
    cout << "Edges of MST are \n";
    int total_weight = g.kruskalMST();
    cout << "\nWeight of MST is " << total_weight;
    return 0;
}